# seedance-animation

A [Claude Code](https://claude.ai/code) skill for generating seamless 5-second loop video animations using [Seedance 2.0](https://docs.kie.ai/market/bytedance/seedance-2) via [KIE.AI](https://kie.ai).

Designed for creating looping intro animations for web pages — provide a reference image and Claude generates a smooth, seamless `.mp4` loop.

---

## Installation

```bash
npx seedance-animation
```

This copies the skill into your project's `.agents/skills/` directory and updates `skills-lock.json`.

---

## Setup

Add your [KIE.AI API key](https://kie.ai) to your project's `.env` file:

```env
KIE_API_KEY=your_key_here
```

The skill reads this automatically — no additional configuration needed.

---

## Usage

Once installed, ask Claude naturally:

```
Generate a seamless loop animation from this image: ./hero-image.jpg
```

```
Create a looping intro animation for my website using https://example.com/image.jpg, aspect ratio 1:1
```

```
Animate this image with floating golden particles: ./background.png
```

Claude will:
1. Build an optimized prompt for seamless loop motion
2. Submit the task to Seedance 2.0 via KIE.AI
3. Poll until the video is ready
4. Download the `.mp4` to your project directory
5. Give you the HTML embed snippet

---

## Output

A 5-second `.mp4` file, ready to embed:

```html
<video autoplay loop muted playsinline>
  <source src="animation.mp4" type="video/mp4">
</video>
```

---

## Parameters

| Parameter | Default | Options |
|---|---|---|
| Duration | 5s | Fixed |
| Resolution | 720p | 480p, 720p |
| Aspect ratio | 16:9 | 1:1, 4:3, 3:4, 16:9, 9:16, 21:9 |
| Audio | Off | — |

---

## Reference image requirements

- Formats: JPEG, PNG, WebP, BMP, TIFF, GIF
- Aspect ratio: 0.4–2.5
- Resolution: 300–6000px per side
- Can be a local file path or an `https://` URL

---

## Requirements

- [Claude Code](https://claude.ai/code)
- Node.js ≥ 18 (for the installer)
- Python 3.8+ (for the generation script)
- A [KIE.AI](https://kie.ai) account with credits

---

## License

MIT
